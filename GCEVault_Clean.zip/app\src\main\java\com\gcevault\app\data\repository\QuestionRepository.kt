package com.gcevault.app.data.repository

import com.gcevault.app.data.local.dao.QuestionDao
import com.gcevault.app.data.local.entity.QuestionEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class QuestionRepository @Inject constructor(
    private val questionDao: QuestionDao
) {
    fun getQuestionsBySubjectAndYear(subject: String, startYear: Int, endYear: Int): Flow<List<QuestionEntity>> {
        return questionDao.getQuestionsBySubjectAndYear(subject, startYear, endYear)
    }

    fun getQuestionsByTopic(subject: String, topic: String): Flow<List<QuestionEntity>> {
        return questionDao.getQuestionsByTopic(subject, topic)
    }

    suspend fun getQuestionById(questionId: String): QuestionEntity? {
        return questionDao.getQuestionById(questionId)
    }

    suspend fun getRandomDailyMCQs(): List<QuestionEntity> {
        return questionDao.getRandomDailyMCQs()
    }

    suspend fun getAllSubjects(): List<String> {
        return questionDao.getAllSubjects()
    }

    suspend fun insertQuestions(questions: List<QuestionEntity>) {
        questionDao.insertQuestions(questions)
    }

    suspend fun getQuestionCount(): Int {
        return questionDao.getQuestionCount()
    }

    // 8. Seed the database with dummy data if it's empty (For testing the UI)
    suspend fun seedDatabase() {
        if (getQuestionCount() == 0) {
            val dummyQuestions = listOf(
                QuestionEntity("BIO_2023_P1_Q1", "Biology", "O-Level", 2023, 1, "1", "Genetics", "MCQ", 1, "What is the powerhouse of the cell?", null, "Mitochondria", "It produces ATP.", false),
                QuestionEntity("MATH_2023_P1_Q1", "Mathematics", "O-Level", 2023, 1, "1", "Algebra", "MCQ", 1, "Solve for x: 2x + 4 = 10", null, "3", "Subtract 4, divide by 2.", false),
                QuestionEntity("PHY_2023_P1_Q1", "Physics", "O-Level", 2023, 1, "1", "Mechanics", "MCQ", 1, "What is the unit of Force?", null, "Newton", "F = ma", false),
                QuestionEntity("CHEM_2023_P1_Q1", "Chemistry", "O-Level", 2023, 1, "1", "Periodic Table", "MCQ", 1, "What is the chemical symbol for Gold?", null, "Au", "From Latin 'Aurum'.", false),
                QuestionEntity("ENG_2023_P1_Q1", "English", "O-Level", 2023, 1, "1", "Grammar", "Essay", 10, "Write a letter to your friend.", null, "Dear Friend...", "Proper format and grammar.", false)
            )
            insertQuestions(dummyQuestions)
        }
    }
}