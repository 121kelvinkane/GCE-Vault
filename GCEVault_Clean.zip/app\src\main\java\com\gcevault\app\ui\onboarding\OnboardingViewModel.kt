package com.gcevault.app.ui.onboarding

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gcevault.app.data.repository.QuestionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

data class OnboardingState(
    val currentStep: Int = 0,
    val selectedLevel: String = "",
    val selectedSubjects: List<String> = emptyList(),
    val availableSubjects: List<String> = emptyList(),
    val gceDate: Long = 0,
    val isDownloading: Boolean = false,
    val downloadProgress: Float = 0f,
    val isComplete: Boolean = false
)

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    private val repository: QuestionRepository
) : ViewModel() {

    private val _state = MutableStateFlow(OnboardingState())
    val state: StateFlow<OnboardingState> = _state

    init {
        seedAndLoadSubjects()
        setDefaultGCEDate()
    }

    private fun seedAndLoadSubjects() {
        viewModelScope.launch {
            // 1. Insert dummy data if the database is empty
            repository.seedDatabase()

            // 2. Now fetch the subjects (it will find the 5 we just added!)
            val subjects = repository.getAllSubjects()
            _state.value = _state.value.copy(availableSubjects = subjects)
        }
    }
    private fun loadSubjects() {
        viewModelScope.launch {
            // Fetches subjects from our offline database!
            val subjects = repository.getAllSubjects()
            _state.value = _state.value.copy(availableSubjects = subjects)
        }
    }

    private fun setDefaultGCEDate() {
        val calendar = Calendar.getInstance().apply {
            set(2027, Calendar.JUNE, 15) // Default to June 15, 2027
        }
        _state.value = _state.value.copy(gceDate = calendar.timeInMillis)
    }

    fun nextStep() {
        if (_state.value.currentStep < 4) {
            _state.value = _state.value.copy(currentStep = _state.value.currentStep + 1)
        }
    }

    fun previousStep() {
        if (_state.value.currentStep > 0) {
            _state.value = _state.value.copy(currentStep = _state.value.currentStep - 1)
        }
    }

    fun selectLevel(level: String) {
        _state.value = _state.value.copy(selectedLevel = level)
    }

    fun toggleSubject(subject: String) {
        val current = _state.value.selectedSubjects.toMutableList()
        if (current.contains(subject)) {
            current.remove(subject)
        } else {
            if (current.size < 10) current.add(subject)
        }
        _state.value = _state.value.copy(selectedSubjects = current)
    }

    fun startDownload() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isDownloading = true, downloadProgress = 0f)

            // Simulate download progress for the UI
            for (i in 1..100) {
                kotlinx.coroutines.delay(30)
                _state.value = _state.value.copy(downloadProgress = i / 100f)
            }

            // TODO: Save user preferences to a UserProgressRepository here

            _state.value = _state.value.copy(isDownloading = false, isComplete = true)
        }
    }
}