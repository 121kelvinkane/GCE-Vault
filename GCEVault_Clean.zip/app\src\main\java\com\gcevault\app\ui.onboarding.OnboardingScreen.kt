package com.gcevault.app.ui.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.gcevault.app.ui.theme.GCEGreen

@Composable
fun OnboardingScreen(
    onOnboardingComplete: () -> Unit,
    viewModel: OnboardingViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    // 🎉 NEW: If download is complete, show the success screen!
    if (state.isComplete) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Vault Ready!", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = GCEGreen)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Your offline questions are downloaded.", fontSize = 16.sp, color = androidx.compose.ui.graphics.Color.Gray)
            Spacer(modifier = Modifier.height(48.dp))
            Button(onClick = onOnboardingComplete, colors = ButtonDefaults.buttonColors(containerColor = GCEGreen)) {
                Text("Enter the Vault", fontSize = 18.sp)
            }
        }
        return // Stop here, don't show the onboarding steps
    }

    // The rest of the onboarding steps
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        when (state.currentStep) {
            0 -> WelcomeStep(onNext = viewModel::nextStep)
            1 -> LevelStep(
                selectedLevel = state.selectedLevel,
                onLevelSelected = viewModel::selectLevel,
                onNext = viewModel::nextStep,
                onBack = viewModel::previousStep
            )
            2 -> SubjectStep(
                availableSubjects = state.availableSubjects,
                selectedSubjects = state.selectedSubjects,
                onSubjectToggled = viewModel::toggleSubject,
                onNext = viewModel::nextStep,
                onBack = viewModel::previousStep
            )
            3 -> DateStep(
                onNext = viewModel::nextStep,
                onBack = viewModel::previousStep
            )
            4 -> DownloadStep(
                subjects = state.selectedSubjects,
                isDownloading = state.isDownloading,
                progress = state.downloadProgress,
                onStartDownload = viewModel::startDownload
            )
        }
    }
}

@Composable
fun WelcomeStep(onNext: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Pass GCE.", fontSize = 48.sp, fontWeight = FontWeight.Bold, color = GCEGreen)
        Text("Not Luck.", fontSize = 32.sp, color = GCEGreen)
        Spacer(modifier = Modifier.height(48.dp))
        Button(onClick = onNext, colors = ButtonDefaults.buttonColors(containerColor = GCEGreen)) {
            Text("Get Started", fontSize = 18.sp)
        }
    }
}

@Composable
fun LevelStep(selectedLevel: String, onLevelSelected: (String) -> Unit, onNext: () -> Unit, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Pick Your Level", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(48.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            OutlinedButton(
                onClick = { onLevelSelected("O-Level") },
                modifier = Modifier.weight(1f),
                colors = if (selectedLevel == "O-Level") ButtonDefaults.outlinedButtonColors(containerColor = GCEGreen) else ButtonDefaults.outlinedButtonColors()
            ) {
                Text("O-Level", color = if (selectedLevel == "O-Level") androidx.compose.ui.graphics.Color.White else GCEGreen)
            }
            Spacer(modifier = Modifier.width(16.dp))
            OutlinedButton(
                onClick = { onLevelSelected("A-Level") },
                modifier = Modifier.weight(1f),
                colors = if (selectedLevel == "A-Level") ButtonDefaults.outlinedButtonColors(containerColor = GCEGreen) else ButtonDefaults.outlinedButtonColors()
            ) {
                Text("A-Level", color = if (selectedLevel == "A-Level") androidx.compose.ui.graphics.Color.White else GCEGreen)
            }
        }
        Spacer(modifier = Modifier.height(48.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = onBack) { Text("Back") }
            Spacer(modifier = Modifier.weight(1f))
            Button(onClick = onNext, enabled = selectedLevel.isNotEmpty(), colors = ButtonDefaults.buttonColors(containerColor = GCEGreen)) {
                Text("Next")
            }
        }
    }
}

@Composable
fun SubjectStep(availableSubjects: List<String>, selectedSubjects: List<String>, onSubjectToggled: (String) -> Unit, onNext: () -> Unit, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Pick Your Subjects", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Min 3, Max 10", fontSize = 16.sp, color = androidx.compose.ui.graphics.Color.Gray)
        Spacer(modifier = Modifier.height(24.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(availableSubjects) { subject ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = selectedSubjects.contains(subject),
                        onCheckedChange = { onSubjectToggled(subject) },
                        colors = CheckboxDefaults.colors(checkedColor = GCEGreen)
                    )
                    Text(subject, fontSize = 18.sp)
                }
            }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = onBack) { Text("Back") }
            Spacer(modifier = Modifier.weight(1f))
            Button(onClick = onNext, enabled = selectedSubjects.size >= 3, colors = ButtonDefaults.buttonColors(containerColor = GCEGreen)) {
                Text("Next")
            }
        }
    }
}

@Composable
fun DateStep(onNext: () -> Unit, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Set GCE Date", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(48.dp))
        Text("June 15, 2027", fontSize = 24.sp, color = GCEGreen)
        Spacer(modifier = Modifier.height(48.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = onBack) { Text("Back") }
            Spacer(modifier = Modifier.weight(1f))
            Button(onClick = onNext, colors = ButtonDefaults.buttonColors(containerColor = GCEGreen)) {
                Text("Next")
            }
        }
    }
}

@Composable
fun DownloadStep(subjects: List<String>, isDownloading: Boolean, progress: Float, onStartDownload: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("Download Questions", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Downloading ${subjects.joinToString(", ")}...", fontSize = 16.sp, color = androidx.compose.ui.graphics.Color.Gray)
        Spacer(modifier = Modifier.height(48.dp))
        if (isDownloading) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = GCEGreen)
            Spacer(modifier = Modifier.height(16.dp))
            Text("${(progress * 100).toInt()}%", fontSize = 24.sp)
        } else {
            Button(onClick = onStartDownload, colors = ButtonDefaults.buttonColors(containerColor = GCEGreen)) {
                Text("Start Download", fontSize = 18.sp)
            }
        }
    }
}