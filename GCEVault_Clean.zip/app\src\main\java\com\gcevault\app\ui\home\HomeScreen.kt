package com.gcevault.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.gcevault.app.ui.home.HomeScreen
import com.gcevault.app.ui.onboarding.OnboardingScreen
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            // Set to FALSE to show the Onboarding questions first!
            var isOnboardingComplete by remember { mutableStateOf(false) }
            val context = LocalContext.current

            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (isOnboardingComplete) {
                        // 🏠 THIS IS THE ACTUAL NEW HOME SCREEN!
                        HomeScreen(
                            onNavigateToDaily3 = {
                                Toast.makeText(context, "Opening Daily 3...", Toast.LENGTH_SHORT).show()
                            },
                            onNavigateToQuestionBank = {
                                Toast.makeText(context, "Opening Question Bank...", Toast.LENGTH_SHORT).show()
                            },
                            onNavigateToScan = {
                                Toast.makeText(context, "Opening Camera...", Toast.LENGTH_SHORT).show()
                            }
                        )
                    } else {
                        //  THIS IS THE ONBOARDING SCREEN (The Questions)
                        OnboardingScreen(
                            onOnboardingComplete = {
                                isOnboardingComplete = true
                            }
                        )
                    }
                }
            }
        }
    }
}