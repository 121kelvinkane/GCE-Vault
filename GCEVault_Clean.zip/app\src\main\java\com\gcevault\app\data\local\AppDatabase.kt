package com.gcevault.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.gcevault.app.data.local.dao.QuestionDao
import com.gcevault.app.data.local.entity.QuestionEntity

@Database(
    entities = [QuestionEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    // This gives us access to the QuestionDao we just built
    abstract fun questionDao(): QuestionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            // If the database already exists, return it
            return INSTANCE ?: synchronized(this) {
                // Otherwise, create a new database
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "gce_vault_database" // This is the name of the actual file on the phone
                )
                    .fallbackToDestructiveMigration() // Resets DB if we change the blueprint later during dev
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}