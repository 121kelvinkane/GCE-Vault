package com.gcevault.app.data.local.dao

import androidx.room.*
import com.gcevault.app.data.local.entity.QuestionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface QuestionDao {

    // 1. Get questions for a specific subject and year range
    @Query("SELECT * FROM questions WHERE subject = :subject AND year BETWEEN :startYear AND :endYear ORDER BY year DESC")
    fun getQuestionsBySubjectAndYear(subject: String, startYear: Int, endYear: Int): Flow<List<QuestionEntity>>

    // 2. Get questions for a specific topic
    @Query("SELECT * FROM questions WHERE subject = :subject AND topic = :topic")
    fun getQuestionsByTopic(subject: String, topic: String): Flow<List<QuestionEntity>>

    // 3. Get a single question by its ID
    @Query("SELECT * FROM questions WHERE questionId = :questionId")
    suspend fun getQuestionById(questionId: String): QuestionEntity?

    // 4. Get 3 random MCQs for the "Daily 3" feature
    @Query("SELECT * FROM questions WHERE type = 'MCQ' ORDER BY RANDOM() LIMIT 3")
    suspend fun getRandomDailyMCQs(): List<QuestionEntity>

    // 5. Get all unique subjects
    @Query("SELECT DISTINCT subject FROM questions")
    suspend fun getAllSubjects(): List<String>

    // 6. Insert a list of questions
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestions(questions: List<QuestionEntity>)

    // 7. Check how many questions are in the database
    @Query("SELECT COUNT(*) FROM questions")
    suspend fun getQuestionCount(): Int
}