package com.gcevault.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "questions")
data class QuestionEntity(
    @PrimaryKey
    val questionId: String,         // e.g., "BIO_2019_P2_Q5b"
    val subject: String,            // e.g., "Biology"
    val level: String,              // "O-Level" or "A-Level"
    val year: Int,                  // e.g., 2019
    val paper: Int,                 // e.g., 2
    val questionNumber: String,     // e.g., "5b"
    val topic: String,              // e.g., "Genetics"
    val type: String,               // "MCQ" or "Essay"
    val marks: Int,                 // e.g., 4
    val questionText: String,       // The actual question
    val options: String?,           // JSON string for MCQ options (null for Essay)
    val correctAnswer: String,      // The right answer or model answer summary
    val explanation: String,        // Why it's correct / Marking rubric points
    val isDownloaded: Boolean = false // True if fully cached for offline use
)